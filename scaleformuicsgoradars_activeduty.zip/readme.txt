Thanks for downloading this project to revert the CS:GO radars to their superior selves!
I've decided to split these radars into 2 .zip files. 1 containing the Active Duty/Commonly Played Maps and the other containing everything else. 
I was forced to do this because github has a 25mb limit on files.
This is the Active Duty/Commonly Played Maps file.

Known issues/bugs:

-Cache, Militia, Vertigo, Cobblestone and Canals still have the panorama radar image.

I have my reasoning for all of these ones not being included, starting from the top:

Cache:
	This is because panorama had been rolled out before the Cache rework and FMPONE must've changed the map's place in the editor meaning that if I try to port
	the old radar into the game, it won't line up properly henceforth I decided to leave it how it is. Anyone who knows their stuff, please contact me!

Militia:
	Pretty much the same reason as for Cache, I have a scaleform version but I can't get it to line up properly.

Vertigo:
	Vertigo has received several major layout changes before and after the godforsaken Panorama UI update, meaning a proper Scaleform version of it's current layout
	simply does not exist. I could attempt to recreate it myself but I don't know how to make radars in the Scaleform style.

Cobblestone:
	Cobblestone got a major update in October, 2018. That's 4 months after the Panorama UI was added to the game. Meaning that a Scaleform version of it's radar image 
	does not exist. Again I could try recreate it but I don't know how.

Canals:
	Same reasons as before, stupid Scaleform radar thingy didn't exist and I can't use something that doesn't exist but oh well no one plays Canals anyways

-Any map newer than June 2018 doesn't have a radar.
	Yeah well, obviously. That's the month in which the Panorama UI got added to the game. So obviously no one made radar overviews in the old style.


If you happen to know how to make radars in the Scaleform style please don't hesitate to contact me!

Credits (from where I found and edited these radar overviews):
A late 2015 build of CS:GO my friend found.
3kliksphilip for his decompiled map downloads from 2017 which just happened to have the radars from 2017 included
in them.

Links:
https://drive.google.com/file/d/1zKo8L28dr9kgZfEMSTmpy7HjVX7kGNt6/view (The late 2015 build of the game)
https://3kliksphilip.com - Please check out 3kliksphilip he's an awesome and very respectable guy who makes great videos.